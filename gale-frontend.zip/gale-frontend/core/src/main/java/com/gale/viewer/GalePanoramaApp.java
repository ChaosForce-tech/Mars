package com.gale.viewer;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.assets.loaders.ModelLoader;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Mesh;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.loader.ObjLoader;
import com.badlogic.gdx.graphics.g3d.utils.CameraInputController;
import com.badlogic.gdx.graphics.g3d.utils.MeshPartBuilder;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.collision.BoundingBox;
import com.badlogic.gdx.math.collision.Ray;

import java.util.ArrayList;
import java.util.List;

public class GalePanoramaApp extends ApplicationAdapter {
    private PerspectiveCamera camera;
    private CameraInputController camController;
    private ModelBatch modelBatch;
    private Environment environment;

    private Model craterModel;
    private ModelInstance craterInstance;

    private SpriteBatch uiBatch;
    private BitmapFont font;
    private String coordsText = "Hover over crater | RMB: Set Point A";

    // Рендерер для линий визуализации прицела наведения
    private ShapeRenderer shapeRenderer;
    private Vector3 hoverHitPoint = null;

    // Географические константы кратера Гейла
    private static final float CENTER_LAT = -5.4f;
    private static final float CENTER_LON = 137.8f;
    private static final float DEG_SPAN = 3.38f;
    private static final float MODEL_SIZE = 100f;

    // Минимальный зазор камеры над поверхностью рельефа
    private static final float MIN_CAMERA_CLEARANCE = 3.5f;

    private float[] craterTriangles;

    // Маркеры точек А (старт) и Б (финиш)
    private Model startMarkerModel, endMarkerModel;
    private ModelInstance startMarker, endMarker;

    // Координаты в формате [lat, lon]
    private float[] startLatLon = null;
    private float[] endLatLon = null;

    // 3D-модели маршрута и зоны заражения
    private Model routeModel;
    private ModelInstance routeInstance;

    private Model hazardModel;
    private ModelInstance hazardInstance;

    @Override
    public void create() {
        modelBatch = new ModelBatch();
        uiBatch = new SpriteBatch();
        shapeRenderer = new ShapeRenderer();

        font = new BitmapFont();
        font.getData().setScale(1.4f);
        font.setColor(Color.WHITE);

        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.4f, 0.4f, 0.4f, 1f));
        environment.add(new DirectionalLight().set(0.9f, 0.85f, 0.8f, -1f, -0.8f, -0.5f));

        camera = new PerspectiveCamera(67, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.position.set(0f, 80f, 100f);
        camera.lookAt(0f, 0f, 0f);
        camera.near = 0.5f;
        camera.far = 1000f;
        camera.update();

        camController = new CameraInputController(camera);
        camController.scrollFactor = -1.0f;

        // Загрузка и масштабирование модели кратера
        ModelLoader<?> loader = new ObjLoader();
        craterModel = loader.loadModel(Gdx.files.internal("gale_crater.obj"));
        craterInstance = new ModelInstance(craterModel);

        BoundingBox bounds = new BoundingBox();
        craterInstance.calculateBoundingBox(bounds);
        Vector3 center = new Vector3();
        Vector3 dimensions = new Vector3();
        bounds.getCenter(center);
        bounds.getDimensions(dimensions);
        float maxDim = Math.max(dimensions.x, Math.max(dimensions.y, dimensions.z));
        float scale = MODEL_SIZE / maxDim;

        craterInstance.transform.setToScaling(scale, scale, scale);
        craterInstance.transform.translate(-center.x, -center.y, -center.z);

        for (Material mat : craterInstance.materials) {
            mat.set(ColorAttribute.createDiffuse(0.76f, 0.45f, 0.32f, 1f));
        }

        extractMeshData();

        // Создаем 3D-маркеры
        ModelBuilder mb = new ModelBuilder();
        long attrs = VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal;
        startMarkerModel = mb.createSphere(2.0f, 2.0f, 2.0f, 16, 16,
            new Material(ColorAttribute.createDiffuse(Color.GREEN)), attrs);
        endMarkerModel = mb.createSphere(2.0f, 2.0f, 2.0f, 16, 16,
            new Material(ColorAttribute.createDiffuse(Color.BLUE)), attrs);

        // Тестовая точка Б (центр кратера / гора Шарп)
        setEndCoordinates(-5.45f, 137.85f);

        // Фиксированная тестовая зона заражения
        List<float[]> mockHazardZone = new ArrayList<>();
        mockHazardZone.add(new float[]{-5.20f, 137.50f});
        mockHazardZone.add(new float[]{-5.20f, 137.75f});
        mockHazardZone.add(new float[]{-5.40f, 137.75f});
        mockHazardZone.add(new float[]{-5.40f, 137.50f});
        setHazardZone(mockHazardZone);

        // Обработка ввода
        InputMultiplexer multiplexer = new InputMultiplexer();
        multiplexer.addProcessor(new InputAdapter() {
            @Override
            public boolean touchDown(int screenX, int screenY, int pointer, int button) {
                if (button == Input.Buttons.RIGHT) {
                    handleRightClick(screenX, screenY);
                    return true;
                }
                return false;
            }
        });
        multiplexer.addProcessor(camController);
        Gdx.input.setInputProcessor(multiplexer);
    }

    // =========================================================================
    // ГЕТТЕРЫ И СЕТТЕРЫ ДЛЯ ОБМЕНА КООРДИНАТАМИ
    // =========================================================================

    public float[] getStartCoordinates() {
        return startLatLon;
    }

    public void setStartCoordinates(float lat, float lon) {
        this.startLatLon = new float[]{lat, lon};
        Vector3 pos3D = geoToWorld3D(lat, lon);
        if (pos3D != null) {
            startMarker = new ModelInstance(startMarkerModel);
            startMarker.transform.setTranslation(pos3D);
            rebuildDirectRouteIfReady();
        }
    }

    public float[] getEndCoordinates() {
        return endLatLon;
    }

    public void setEndCoordinates(float lat, float lon) {
        this.endLatLon = new float[]{lat, lon};
        Vector3 pos3D = geoToWorld3D(lat, lon);
        if (pos3D != null) {
            endMarker = new ModelInstance(endMarkerModel);
            endMarker.transform.setTranslation(pos3D);
            rebuildDirectRouteIfReady();
        }
    }

    public void setRoute(List<float[]> waypointsLatLon) {
        if (routeModel != null) {
            routeModel.dispose();
            routeModel = null;
            routeInstance = null;
        }
        if (waypointsLatLon == null || waypointsLatLon.size() < 2) return;

        ModelBuilder mb = new ModelBuilder();
        mb.begin();
        MeshPartBuilder builder = mb.part("route", GL20.GL_LINES,
            VertexAttributes.Usage.Position | VertexAttributes.Usage.ColorUnpacked,
            new Material());
        builder.setColor(Color.YELLOW);

        for (int i = 0; i < waypointsLatLon.size() - 1; i++) {
            float[] p1 = waypointsLatLon.get(i);
            float[] p2 = waypointsLatLon.get(i + 1);
            drawSegmentedLineOnTerrain(builder, p1[0], p1[1], p2[0], p2[1], 35);
        }

        routeModel = mb.end();
        routeInstance = new ModelInstance(routeModel);
    }

    public void setHazardZone(List<float[]> polygonLatLon) {
        if (hazardModel != null) {
            hazardModel.dispose();
            hazardModel = null;
            hazardInstance = null;
        }
        if (polygonLatLon == null || polygonLatLon.size() < 3) return;

        ModelBuilder mb = new ModelBuilder();
        mb.begin();
        MeshPartBuilder builder = mb.part("hazard", GL20.GL_LINES,
            VertexAttributes.Usage.Position | VertexAttributes.Usage.ColorUnpacked,
            new Material());
        builder.setColor(Color.RED);

        for (int i = 0; i < polygonLatLon.size(); i++) {
            float[] p1 = polygonLatLon.get(i);
            float[] p2 = polygonLatLon.get((i + 1) % polygonLatLon.size());
            drawSegmentedLineOnTerrain(builder, p1[0], p1[1], p2[0], p2[1], 30);
        }

        hazardModel = mb.end();
        hazardInstance = new ModelInstance(hazardModel);
    }

    // =========================================================================
    // ПОСТРОЕНИЕ ЛИНИЙ, ЗАЩИТА КАМЕРЫ И ПЕРЕВОД КООРДИНАТ
    // =========================================================================

    private void rebuildDirectRouteIfReady() {
        if (startLatLon != null && endLatLon != null) {
            List<float[]> directPath = new ArrayList<>();
            directPath.add(startLatLon);
            directPath.add(endLatLon);
            setRoute(directPath);
        }
    }

    private void drawSegmentedLineOnTerrain(MeshPartBuilder builder, float lat1, float lon1, float lat2, float lon2, int steps) {
        Vector3 prevPoint = null;
        for (int s = 0; s <= steps; s++) {
            float t = (float) s / steps;
            float lat = lat1 + (lat2 - lat1) * t;

            float lon = lon1 + (lon2 - lon1) * t;
            Vector3 currentPoint = geoToWorld3D(lat, lon);
            if (currentPoint != null) {
                currentPoint.y += 0.4f;
                if (prevPoint != null) {
                    builder.line(prevPoint, currentPoint);
                }
                prevPoint = currentPoint;
            }
        }
    }
    /** Не позволяет камере опускаться ниже поверхности рельефа */
    private void enforceCameraTerrainCollision() {
        float groundY = getGroundHeight(camera.position.x, camera.position.z);
        float minAllowedY = groundY + MIN_CAMERA_CLEARANCE;
        if (camera.position.y < minAllowedY) {
            camera.position.y = minAllowedY;
            camera.update();
        }
    }
    /** Отрисовывает вертикальный луч и перекрестие в точке наведения курсора */
    private void drawHoverCrosshair() {
        if (hoverHitPoint == null) return;
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);
        shapeRenderer.setProjectionMatrix(camera.combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
        shapeRenderer.setColor(Color.CYAN);
        float x = hoverHitPoint.x;
        float y = hoverHitPoint.y + 0.15f;
        float z = hoverHitPoint.z;
        float crossSize = 3.0f;
// Вертикальный луч от поверхности вверх
        shapeRenderer.line(x, y, z, x, y + 12f, z);
// Горизонтальное перекрестие (оси X и Z)
        shapeRenderer.line(x - crossSize, y, z, x + crossSize, y, z);
        shapeRenderer.line(x, y, z - crossSize, x, y, z + crossSize);
        shapeRenderer.end();
    }
    private Vector3 geoToWorld3D(float lat, float lon) {
        float worldX = lonToWorldX(lon);
        float worldZ = latToWorldZ(lat);
        float groundY = getGroundHeight(worldX, worldZ);
        return new Vector3(worldX, groundY, worldZ);
    }
    private float getGroundHeight(float worldX, float worldZ) {
        Ray downRay = new Ray(new Vector3(worldX, 200f, worldZ), new Vector3(0f, -1f, 0f));
        Vector3 hit = new Vector3();
        if (intersectCrater(downRay, hit)) {
            return hit.y;
        }
        return -15f;
    }
    private float lonToWorldX(float lon) {
        return ((lon - CENTER_LON) / DEG_SPAN) * MODEL_SIZE;
    }
    private float latToWorldZ(float lat) {
        return -((lat - CENTER_LAT) / DEG_SPAN) * MODEL_SIZE;
    }
    private float worldXToLon(float worldX) {
        return CENTER_LON + ((worldX / MODEL_SIZE) * DEG_SPAN);
    }
    private float worldZToLat(float worldZ) {
        return CENTER_LAT + ((-worldZ / MODEL_SIZE) * DEG_SPAN);
    }
    private String formatCoord(float value) {
        float rounded = Math.round(value * 100000f) / 100000f;
        return Float.toString(rounded);
    }
    // =========================================================================
// ОБРАБОТКА КЛИКОВ И РЕНДЕРИНГ
// =========================================================================
    private void handleRightClick(int screenX, int screenY) {
        Ray ray = camera.getPickRay(screenX, screenY);
        Vector3 hitPoint = new Vector3();
        if (intersectCrater(ray, hitPoint)) {
            float lat = worldZToLat(hitPoint.z);
            float lon = worldXToLon(hitPoint.x);
            setStartCoordinates(lat, lon);
            Gdx.app.log("MARS", "Point A set -> Lat: " + lat + ", Lon: " + lon);
        }
    }
    private void updateHoverCoordinates(int screenX, int screenY) {
        Ray ray = camera.getPickRay(screenX, screenY);
        Vector3 hit = new Vector3();
        if (intersectCrater(ray, hit)) {
            hoverHitPoint = new Vector3(hit);
            float lat = worldZToLat(hit.z);
            float lon = worldXToLon(hit.x);
            coordsText = "Lat: " + formatCoord(lat) + " deg, Lon: " + formatCoord(lon) + " deg";
        } else {
            hoverHitPoint = null;
            coordsText = "Outside map";
        }
    }
    private void extractMeshData() {
        int totalTriangles = 0;
        for (Mesh mesh : craterModel.meshes) {
            int numIndices = mesh.getNumIndices();
            totalTriangles += (numIndices > 0) ? (numIndices / 3) : (mesh.getNumVertices() / 3);
        }
        craterTriangles = new float[totalTriangles * 9];
        int triOffset = 0;
        Vector3 v1 = new Vector3();
        Vector3 v2 = new Vector3();
        Vector3 v3 = new Vector3();
        for (Mesh mesh : craterModel.meshes) {
            int numVertices = mesh.getNumVertices();
            int vertexSize = mesh.getVertexSize() / 4;
            float[] rawVertices = new float[numVertices * vertexSize];
            mesh.getVertices(rawVertices);
            int numIndices = mesh.getNumIndices();
            if (numIndices > 0) {
                short[] rawIndices = new short[numIndices];
                mesh.getIndices(rawIndices);
                for (int i = 0; i < numIndices; i += 3) {
                    int idx1 = rawIndices[i] & 0xFFFF;
                    int idx2 = rawIndices[i + 1] & 0xFFFF;
                    int idx3 = rawIndices[i + 2] & 0xFFFF;
                    v1.set(rawVertices[idx1 * vertexSize], rawVertices[idx1 * vertexSize + 1], rawVertices[idx1 * vertexSize + 2]).mul(craterInstance.transform);
                    v2.set(rawVertices[idx2 * vertexSize], rawVertices[idx2 * vertexSize + 1], rawVertices[idx2 * vertexSize + 2]).mul(craterInstance.transform);
                    v3.set(rawVertices[idx3 * vertexSize], rawVertices[idx3 * vertexSize + 1], rawVertices[idx3 * vertexSize + 2]).mul(craterInstance.transform);
                    craterTriangles[triOffset++] = v1.x; craterTriangles[triOffset++] = v1.y; craterTriangles[triOffset++] = v1.z;
                    craterTriangles[triOffset++] = v2.x; craterTriangles[triOffset++] = v2.y; craterTriangles[triOffset++] = v2.z;
                    craterTriangles[triOffset++] = v3.x; craterTriangles[triOffset++] = v3.y; craterTriangles[triOffset++] = v3.z;
                }
            } else {
                for (int i = 0; i < numVertices; i += 3) {
                    v1.set(rawVertices[i * vertexSize], rawVertices[i * vertexSize + 1], rawVertices[i * vertexSize + 2]).mul(craterInstance.transform);
                    v2.set(rawVertices[(i + 1) * vertexSize], rawVertices[(i + 1) * vertexSize + 1], rawVertices[(i + 1) * vertexSize + 2]).mul(craterInstance.transform);
                    v3.set(rawVertices[(i + 2) * vertexSize], rawVertices[(i + 2) * vertexSize + 1], rawVertices[(i + 2) * vertexSize + 2]).mul(craterInstance.transform);
                    craterTriangles[triOffset++] = v1.x; craterTriangles[triOffset++] = v1.y; craterTriangles[triOffset++] = v1.z;
                    craterTriangles[triOffset++] = v2.x; craterTriangles[triOffset++] = v2.y; craterTriangles[triOffset++] = v2.z;
                    craterTriangles[triOffset++] = v3.x; craterTriangles[triOffset++] = v3.y; craterTriangles[triOffset++] = v3.z;
                }
            }
        }
    }
    private boolean intersectCrater(Ray ray, Vector3 bestHit) {
        if (craterTriangles == null) return false;
        boolean found = false;
        float minDist = Float.MAX_VALUE;
        Vector3 t1 = new Vector3();
        Vector3 t2 = new Vector3();
        Vector3 t3 = new Vector3();
        Vector3 tmpHit = new Vector3();
        for (int i = 0; i < craterTriangles.length; i += 9) {
            t1.set(craterTriangles[i], craterTriangles[i + 1], craterTriangles[i + 2]);
            t2.set(craterTriangles[i + 3], craterTriangles[i + 4], craterTriangles[i + 5]);
            t3.set(craterTriangles[i + 6], craterTriangles[i + 7], craterTriangles[i + 8]);
            if (Intersector.intersectRayTriangle(ray, t1, t2, t3, tmpHit)) {
                float dist = ray.origin.dst2(tmpHit);
                if (dist < minDist) {
                    minDist = dist;
                    bestHit.set(tmpHit);
                    found = true;
                }
            }
        }
        return found;
    }
    @Override
    public void render() {
        camController.update();
        enforceCameraTerrainCollision();
        updateHoverCoordinates(Gdx.input.getX(), Gdx.input.getY());
        Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Gdx.gl.glClearColor(0.08f, 0.08f, 0.1f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        Gdx.gl.glLineWidth(3f);
        modelBatch.begin(camera);
        modelBatch.render(craterInstance, environment);
        if (startMarker != null) modelBatch.render(startMarker, environment);
        if (endMarker != null) modelBatch.render(endMarker, environment);
        if (routeInstance != null) modelBatch.render(routeInstance);
        if (hazardInstance != null) modelBatch.render(hazardInstance);
        modelBatch.end();
// Отрисовка 3D-прицела под курсором
        drawHoverCrosshair();
        uiBatch.begin();
        font.draw(uiBatch, coordsText, 20, 35);
        uiBatch.end();
    }
    @Override
    public void resize(int width, int height) {
        camera.viewportWidth = width;
        camera.viewportHeight = height;
        camera.update();
        uiBatch.getProjectionMatrix().setToOrtho2D(0, 0, width, height);
    }
    @Override
    public void dispose() {
        modelBatch.dispose();
        uiBatch.dispose();
        shapeRenderer.dispose();
        font.dispose();
        craterModel.dispose();
        startMarkerModel.dispose();
        endMarkerModel.dispose();
        if (routeModel != null) routeModel.dispose();
        if (hazardModel != null) hazardModel.dispose();
    }
}
