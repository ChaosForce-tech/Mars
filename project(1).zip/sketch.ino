#include <WiFi.h>
#include <PubSubClient.h>
#include "DHTesp.h"

// ESP32 ADC1 Pins (Safe to use simultaneously with Wi-Fi)
const int RAD_PIN  = 34; // Potentiometer 1: Ionizing Radiation (mSv/hr)
const int SALT_PIN = 33; // Potentiometer 2: Toxic Regolith Perchlorates (%)
const int ATMO_PIN = 35; // Slide Pot: Suit Pressure / CO2 Atmosphere Leak (kPa)
const int DUST_PIN = 32; // Photoresistor AO: Dust Storm Visibility (Optical Lux)
const int TEMP_PIN = 15; // DHT22: Extreme Temperature Swings (Celsius)

const char* SSID = "Wokwi-GUEST";
const char* PASSWORD = "";
const char* MQTT_BROKER = "broker.hivemq.com";
const char* MQTT_TOPIC = "gale_eva_mvp_2026/telemetry";

WiFiClient espClient;
PubSubClient mqtt(espClient);
DHTesp dht;

void reconnectMQTT() {
  while (!mqtt.connected()) {
    String clientId = "GaleSuit-" + String(random(0xffff), HEX);
    if (mqtt.connect(clientId.c_str())) {
      Serial.println("Connected to HiveMQ Broker!");
    } else {
      delay(1500);
    }
  }
}

void setup() {
  Serial.begin(115200);
  analogReadResolution(12); // 0 to 4095
  dht.setup(TEMP_PIN, DHTesp::DHT22);

  WiFi.begin(SSID, PASSWORD, 6);
  Serial.print("Connecting to Wokwi Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }
  Serial.println("\nWi-Fi Connected!");
  mqtt.setServer(MQTT_BROKER, 1883);
}

void loop() {
  if (!mqtt.connected()) {
    reconnectMQTT();
  }
  mqtt.loop();

  // 1. Ionizing Radiation (0.000 to 0.500 mSv/hr)
  float radiation_msv = (analogRead(RAD_PIN) / 4095.0) * 0.500;
  bool rad_hazard = (radiation_msv > 0.100);

  // 2. Toxic Perchlorate Salts in Regolith (0.00% to 2.00% ClO4-)
  float perchlorate_pct = (analogRead(SALT_PIN) / 4095.0) * 2.00;
  bool salt_hazard = (perchlorate_pct > 0.60);

  // 3. Thin CO2 Atmosphere / Suit Differential Pressure (15.0 to 35.0 kPa)
  // Sliding left drops suit pressure and simulates external CO2 atmosphere infiltration
  float suit_pressure_kpa = 15.0 + (analogRead(ATMO_PIN) / 4095.0) * 20.0;
  bool atmo_hazard = (suit_pressure_kpa < 25.0);

  // 4. Dust Storm Optical Visibility (Photoresistor AO: high ADC = dark/dust storm)
  int raw_ldr = analogRead(DUST_PIN);
  float visibility_pct = (1.0 - (raw_ldr / 4095.0)) * 100.0;
  bool dust_hazard = (visibility_pct < 35.0);

  // 5. Extreme Temperature Fluctuations (-40 C to +80 C on DHT22 slider)
  TempAndHumidity th = dht.getTempAndHumidity();
  float temp_c = isnan(th.temperature) ? -10.0 : th.temperature;
  // Triggers on EITHER extreme cryo cold (< -25 C) OR thermal overload (> 35 C)
  bool temp_hazard = (temp_c < -25.0 || temp_c > 35.0);

  char payload[384];
  snprintf(
    payload, sizeof(payload),
    "{\"radiation_msv_hr\":%.3f,\"perchlorate_pct\":%.2f,\"suit_kpa\":%.1f,"
    "\"visibility_pct\":%.1f,\"temp_c\":%.1f,"
    "\"rad_hazard\":%s,\"salt_hazard\":%s,\"atmo_hazard\":%s,"
    "\"dust_hazard\":%s,\"temp_hazard\":%s}",
    radiation_msv, perchlorate_pct, suit_pressure_kpa,
    visibility_pct, temp_c,
    rad_hazard ? "true" : "false",
    salt_hazard ? "true" : "false",
    atmo_hazard ? "true" : "false",
    dust_hazard ? "true" : "false",
    temp_hazard ? "true" : "false"
  );

  mqtt.publish(MQTT_TOPIC, payload);
  Serial.println(payload);

  delay(1500);
}