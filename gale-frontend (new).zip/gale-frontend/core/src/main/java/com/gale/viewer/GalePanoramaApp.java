package com.gale.viewer;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Net;
import com.badlogic.gdx.assets.loaders.ModelLoader;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Mesh;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.loader.ObjLoader;
import com.badlogic.gdx.graphics.g3d.utils.CameraInputController;
import com.badlogic.gdx.graphics.g3d.utils.MeshPartBuilder;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.collision.BoundingBox;
import com.badlogic.gdx.math.collision.Ray;
import com.badlogic.gdx.utils.JsonReader;
import com.badlogic.gdx.utils.JsonValue;

import java.util.ArrayList;
import java.util.List;

public class GalePanoramaApp extends ApplicationAdapter {
    private static final String BACKEND_URL = "http://localhost:5000";

    // Official NASA MGS MOLA Gale Crater / Aeolis Mons 3D Model Constants
    public static final float CENTER_LAT = -5.40f;
    public static final float CENTER_LON = 137.80f;
    public static final float DEG_SPAN = 3.38f;
    public static final float MODEL_SIZE = 100f;
    public static final int GRID_SIZE = 20;

    public static final float GALE_LAT_MIN = CENTER_LAT - (DEG_SPAN / 2.0f); // -7.09 deg
    public static final float GALE_LAT_MAX = CENTER_LAT + (DEG_SPAN / 2.0f); // -3.71 deg
    public static final float GALE_LON_MIN = CENTER_LON - (DEG_SPAN / 2.0f); // 136.11 deg
    public static final float GALE_LON_MAX = CENTER_LON + (DEG_SPAN / 2.0f); // 139.49 deg

    private static final float MIN_CAMERA_CLEARANCE = 3.5f;
    private static final float POLL_INTERVAL_SEC = 0.60f;

    private PerspectiveCamera camera;
    private CameraInputController camController;
    private ModelBatch modelBatch;
    private Environment environment;
    private DirectionalLight sunLight;

    private Model craterModel;
    private ModelInstance craterInstance;
    private float[] craterTriangles;

    private SpriteBatch uiBatch;
    private BitmapFont font;
    private ShapeRenderer shapeRenderer;
    private Vector3 hoverHitPoint = null;

    // 3D Markers for Point A (Start) and Point B (Target)
    private Model startMarkerModel, endMarkerModel;
    private ModelInstance startMarker, endMarker;

    private float[] startLatLon = null;
    private float[] endLatLon = null;

    // 3D Route & Multi-Hazard Models draped over the crater mesh
    private Model routeModel;
    private ModelInstance routeInstance;

    private Model hazardModel;
    private ModelInstance hazardInstance;

    // Backend & Wokwi Live Telemetry State
    private final JsonReader jsonReader = new JsonReader();
    private float pollTimer = 0f;
    private boolean pollInFlight = false;
    private int lastSyncedVersion = -1;

    private String coordsText = "Hover over Gale Crater | RMB: Set Point A | Shift+RMB / MMB: Set Point B";
    private String telemetryHeader = "WOKWI TELEMETRY: Connecting to http://localhost:5000 ...";
    private String hazardBanner = "ACTIVE HAZARDS: NONE";
    private String routeMetricsText = "Route: -- km | Est. Time: -- min | Suit O2: --%";
    private String pointAInfo = "Point A: --";
    private String pointBInfo = "Point B: --";
    private final List<String> navInstructions = new ArrayList<>();
    private boolean dustStormActive = false;

    public static class HazardCell3D {
        public float latMin, latMax, lonMin, lonMax;
        public int type;

        public HazardCell3D(float latMin, float latMax, float lonMin, float lonMax, int type) {
            this.latMin = latMin;
            this.latMax = latMax;
            this.lonMin = lonMin;
            this.lonMax = lonMax;
            this.type = type;
        }
    }

    @Override
    public void create() {
        modelBatch = new ModelBatch();
        uiBatch = new SpriteBatch();
        shapeRenderer = new ShapeRenderer();

        font = new BitmapFont();
        font.getData().setScale(1.15f);
        font.setColor(Color.WHITE);

        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.42f, 0.40f, 0.38f, 1f));
        sunLight = new DirectionalLight().set(0.92f, 0.85f, 0.78f, -1f, -0.8f, -0.5f);
        environment.add(sunLight);

        camera = new PerspectiveCamera(67, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.position.set(0f, 75f, 95f);
        camera.lookAt(0f, 0f, 0f);
        camera.near = 0.5f;
        camera.far = 1000f;
        camera.update();

        camController = new CameraInputController(camera);
        camController.scrollFactor = -1.0f;
        // Free up Right-Click for Point A/B selection by mapping camera pan to Middle/Left+Ctrl
        camController.translateButton = Input.Buttons.BACK;

        ModelLoader<?> loader = new ObjLoader();
        craterModel = loader.loadModel(Gdx.files.internal("gale_crater.obj"));
        craterInstance = new ModelInstance(craterModel);

        BoundingBox bounds = new BoundingBox();
        craterInstance.calculateBoundingBox(bounds);
        Vector3 center = new Vector3();
        Vector3 dimensions = new Vector3();
        bounds.getCenter(center);
        bounds.getDimensions(dimensions);
        float maxDim = Math.max(dimensions.x, Math.max(dimensions.y, dimensions.z));
        float scale = MODEL_SIZE / maxDim;

        craterInstance.transform.setToScaling(scale, scale, scale);
        craterInstance.transform.translate(-center.x, -center.y, -center.z);

        for (Material mat : craterInstance.materials) {
            mat.set(ColorAttribute.createDiffuse(0.76f, 0.45f, 0.32f, 1f));
        }

        extractMeshData();

        ModelBuilder mb = new ModelBuilder();
        long attrs = VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal;
        startMarkerModel = mb.createSphere(2.2f, 2.2f, 2.2f, 16, 16,
            new Material(ColorAttribute.createDiffuse(Color.CYAN)), attrs);
        endMarkerModel = mb.createSphere(2.4f, 2.4f, 2.4f, 16, 16,
            new Material(ColorAttribute.createDiffuse(Color.YELLOW)), attrs);

        // Initial NASA Bradbury Landing (Point A) and Aeolis Mons / Mt Sharp (Point B)
        updateStartMarkerOnly(-4.5895f, 137.4417f);
        updateEndMarkerOnly(-5.0800f, 137.8500f);

        InputMultiplexer multiplexer = new InputMultiplexer();
        multiplexer.addProcessor(new InputAdapter() {
            @Override
            public boolean touchDown(int screenX, int screenY, int pointer, int button) {
                if (button == Input.Buttons.RIGHT) {
                    boolean shiftHeld = Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)
                        || Gdx.input.isKeyPressed(Input.Keys.SHIFT_RIGHT);
                    handleMapClick(screenX, screenY, !shiftHeld);
                    return true;
                } else if (button == Input.Buttons.MIDDLE) {
                    handleMapClick(screenX, screenY, false);
                    return true;
                }
                return false;
            }

            @Override
            public boolean keyDown(int keycode) {
                if (keycode == Input.Keys.R) { sendSimKey("r"); return true; }
                if (keycode == Input.Keys.S) { sendSimKey("s"); return true; }
                if (keycode == Input.Keys.D) { sendSimKey("d"); return true; }
                if (keycode == Input.Keys.T) { sendSimKey("t"); return true; }
                if (keycode == Input.Keys.A) { sendSimKey("a"); return true; }
                if (keycode == Input.Keys.C) { sendSimKey("c"); return true; }
                if (keycode == Input.Keys.NUM_1) { sendSimKey("1"); return true; }
                if (keycode == Input.Keys.NUM_2) { sendSimKey("2"); return true; }
                if (keycode == Input.Keys.NUM_3) { sendSimKey("3"); return true; }
                return false;
            }
        });
        multiplexer.addProcessor(camController);
        Gdx.input.setInputProcessor(multiplexer);

        // Trigger immediate initial sync with mars_backend_server.py
        pollBackendState();
    }

    // =========================================================================
    // LIVE BACKEND & WOKWI NETWORK SYNCHRONIZATION
    // =========================================================================

    private void pollBackendState() {
        if (pollInFlight) return;
        pollInFlight = true;

        Net.HttpRequest req = new Net.HttpRequest(Net.HttpMethods.GET);
        req.setUrl(BACKEND_URL + "/api/state?t=" + System.currentTimeMillis());
        req.setTimeOut(2500);

        Gdx.net.sendHttpRequest(req, new Net.HttpResponseListener() {
            @Override
            public void handleHttpResponse(Net.HttpResponse httpResponse) {
                final int status = httpResponse.getStatus().getStatusCode();
                final String body = httpResponse.getResultAsString();
                Gdx.app.postRunnable(new Runnable() {
                    @Override
                    public void run() {
                        pollInFlight = false;
                        if (status >= 200 && status < 300 && body != null && !body.isEmpty()) {
                            applyBackendPacket(body);
                        }
                    }
                });
            }

            @Override
            public void failed(Throwable t) {
                Gdx.app.postRunnable(new Runnable() {
                    @Override
                    public void run() {
                        pollInFlight = false;
                        telemetryHeader = "BACKEND OFFLINE (Start mars_backend_server.py on port 5000)";
                    }
                });
            }

            @Override
            public void cancelled() {
                pollInFlight = false;
            }
        });
    }

    private void sendPointToBackend(boolean isStartPoint, float lat, float lon) {
        String endpoint = isStartPoint ? "/api/start" : "/api/target";
        String url = BACKEND_URL + endpoint + "?lat=" + lat + "&lon=" + lon;

        Net.HttpRequest req = new Net.HttpRequest(Net.HttpMethods.GET);
        req.setUrl(url);
        req.setTimeOut(2500);

        Gdx.net.sendHttpRequest(req, new Net.HttpResponseListener() {
            @Override
            public void handleHttpResponse(Net.HttpResponse httpResponse) {
                final String body = httpResponse.getResultAsString();
                Gdx.app.postRunnable(new Runnable() {
                    @Override
                    public void run() {
                        if (body != null && !body.isEmpty()) {
                            lastSyncedVersion = -1;
                            applyBackendPacket(body);
                        }
                    }
                });
            }

            @Override
            public void failed(Throwable t) {
                Gdx.app.postRunnable(new Runnable() {
                    @Override
                    public void run() {
                        rebuildDirectRouteIfReady();
                    }
                });
            }

            @Override
            public void cancelled() {}
        });
    }

    private void sendSimKey(String key) {
        Net.HttpRequest req = new Net.HttpRequest(Net.HttpMethods.GET);
        req.setUrl(BACKEND_URL + "/api/sim_key?key=" + key);
        req.setTimeOut(2500);

        Gdx.net.sendHttpRequest(req, new Net.HttpResponseListener() {
            @Override
            public void handleHttpResponse(Net.HttpResponse httpResponse) {
                final String body = httpResponse.getResultAsString();
                Gdx.app.postRunnable(new Runnable() {
                    @Override
                    public void run() {
                        if (body != null && !body.isEmpty()) {
                            lastSyncedVersion = -1;
                            applyBackendPacket(body);
                        }
                    }
                });
            }

            @Override
            public void failed(Throwable t) {}

            @Override
            public void cancelled() {}
        });
    }

    private void applyBackendPacket(String jsonStr) {
        try {
            JsonValue root = jsonReader.parse(jsonStr);
            int version = root.getInt("version", 0);
            if (version == lastSyncedVersion && version != 0) {
                return;
            }
            lastSyncedVersion = version;

            // 1. Point A (Visor / Start Location)
            JsonValue ptA = root.get("point_a");
            if (ptA != null) {
                float aLat = ptA.getFloat("lat", -4.5895f);
                float aLon = ptA.getFloat("lon", 137.4417f);
                int aRow = ptA.getInt("row", 5);
                int aCol = ptA.getInt("col", 8);
                String secName = ptA.getString("sector_name", "Gale Surface");
                updateStartMarkerOnly(aLat, aLon);
                pointAInfo = "Point A [" + aRow + "," + aCol + "] " + secName
                    + " (" + formatCoord(aLat) + ", " + formatCoord(aLon) + ")";
            }

            // 2. Point B (Target Location)
            JsonValue ptB = root.get("point_b");
            if (ptB != null) {
                float bLat = ptB.getFloat("lat", -5.0800f);
                float bLon = ptB.getFloat("lon", 137.8500f);
                int bRow = ptB.getInt("row", 8);
                int bCol = ptB.getInt("col", 10);
                String bName = ptB.getString("name", "Target Waypoint");
                updateEndMarkerOnly(bLat, bLon);
                pointBInfo = "Point B [" + bRow + "," + bCol + "] " + bName
                    + " (" + formatCoord(bLat) + ", " + formatCoord(bLon) + ")";
            }

            // 3. Wokwi Suit Telemetry
            JsonValue tel = root.get("wokwi_telemetry");
            if (tel != null) {
                String src = tel.getString("source", "WOKWI");
                float rad = tel.getFloat("radiation_msv_hr", 0.035f);
                float salt = tel.getFloat("perchlorate_pct", 0.10f);
                float kpa = tel.getFloat("suit_kpa", 32.1f);
                float vis = tel.getFloat("visibility_pct", 85.0f);
                float temp = tel.getFloat("temp_c", -10.0f);

                boolean radH = tel.getBoolean("rad_hazard", rad > 0.100f);
                boolean saltH = tel.getBoolean("salt_hazard", salt > 0.60f);
                boolean atmoH = tel.getBoolean("atmo_hazard", kpa < 25.0f);
                boolean dustH = tel.getBoolean("dust_hazard", vis < 35.0f);
                boolean tempH = tel.getBoolean("temp_hazard", temp < -25.0f || temp > 35.0f);

                this.dustStormActive = dustH;
                if (dustH) {
                    sunLight.set(0.95f, 0.55f, 0.25f, -1f, -0.8f, -0.5f);
                } else {
                    sunLight.set(0.92f, 0.85f, 0.78f, -1f, -0.8f, -0.5f);
                }

                telemetryHeader = String.format(
                    "WOKWI [%s] | RAD: %.3f mSv/h | SALT: %.2f%% | SUIT: %.1f kPa | VIS: %.0f%% | TEMP: %.1f C",
                    src, rad, salt, kpa, vis, temp
                );

                List<String> alerts = new ArrayList<>();
                if (radH) alerts.add("RADIATION PLUME");
                if (saltH) alerts.add("PERCHLORATE SALT");
                if (atmoH) alerts.add("SUIT PRESSURE LEAK");
                if (dustH) alerts.add("DUST SQUALL");
                if (tempH) alerts.add(temp < -25f ? "CRYO TRAP" : "THERMAL OVERLOAD");

                hazardBanner = alerts.isEmpty()
                    ? "STATUS: ALL SUIT SENSORS NOMINAL (CLEAR CORRIDOR)"
                    : "ACTIVE WOKWI HAZARDS: " + String.join(" + ", alerts);
            }

            // 4. Route Metrics
            JsonValue metrics = root.get("route_metrics");
            if (metrics != null) {
                float distM = metrics.getFloat("total_distance_m", 0f);
                float timeMin = metrics.getFloat("estimated_walk_time_min", 0f);
                float o2Pct = metrics.getFloat("estimated_o2_cost_pct", 0f);
                routeMetricsText = String.format(
                    "A* Route Distance: %.1f m | Walk Time: %.1f min | Est. Suit O2: %.2f%%",
                    distM, timeMin, o2Pct
                );
            }

            // 5. Rebuild 3D A* Route on Crater Surface
            List<float[]> routeWaypoints = new ArrayList<>();
            JsonValue pathLatLon = root.get("safe_path_latlon");
            if (pathLatLon != null && pathLatLon.size > 0) {
                for (JsonValue pt = pathLatLon.child; pt != null; pt = pt.next) {
                    routeWaypoints.add(new float[]{pt.getFloat(0), pt.getFloat(1)});
                }
            } else {
                JsonValue pathGrid = root.get("safe_path_grid");
                if (pathGrid != null && pathGrid.size > 0) {
                    for (JsonValue pt = pathGrid.child; pt != null; pt = pt.next) {
                        routeWaypoints.add(gridToLatLon(pt.getInt(0), pt.getInt(1)));
                    }
                }
            }
            setRoute(routeWaypoints);

            // 6. Rebuild 3D Hazard Cells on Crater Surface
            List<HazardCell3D> cells3D = new ArrayList<>();
            JsonValue hazCells = root.get("hazard_cells");
            if (hazCells != null && hazCells.size > 0) {
                float cellLatSpan = DEG_SPAN / (GRID_SIZE - 1);
                float cellLonSpan = DEG_SPAN / (GRID_SIZE - 1);
                for (JsonValue hc = hazCells.child; hc != null; hc = hc.next) {
                    int r = hc.getInt("row", 0);
                    int c = hc.getInt("col", 0);
                    int type = hc.getInt("type", 1);
                    float cLat = hc.has("lat") ? hc.getFloat("lat") : gridToLatLon(r, c)[0];
                    float cLon = hc.has("lon") ? hc.getFloat("lon") : gridToLatLon(r, c)[1];
                    cells3D.add(new HazardCell3D(
                        cLat - cellLatSpan * 0.45f,
                        cLat + cellLatSpan * 0.45f,
                        cLon - cellLonSpan * 0.45f,
                        cLon + cellLonSpan * 0.45f,
                        type
                    ));
                }
            }
            setHazardCells(cells3D);

            // 7. Turn-by-turn EVA instructions
            navInstructions.clear();
            JsonValue instr = root.get("turn_by_turn_instructions");
            if (instr != null) {
                for (JsonValue line = instr.child; line != null; line = line.next) {
                    navInstructions.add(line.asString());
                }
            }
        } catch (Exception e) {
            Gdx.app.error("MARS_SYNC", "Failed to parse backend JSON", e);
        }
    }

    public static float[] gridToLatLon(int row, int col) {
        float lat = GALE_LAT_MAX - ((float) row / (GRID_SIZE - 1)) * (GALE_LAT_MAX - GALE_LAT_MIN);
        float lon = GALE_LON_MIN + ((float) col / (GRID_SIZE - 1)) * (GALE_LON_MAX - GALE_LON_MIN);
        return new float[]{lat, lon};
    }

    // =========================================================================
    // COORDINATE GETTERS / SETTERS & 3D MESH BUILDERS
    // =========================================================================

    public float[] getStartCoordinates() {
        return startLatLon;
    }

    public void setStartCoordinates(float lat, float lon) {
        updateStartMarkerOnly(lat, lon);
        sendPointToBackend(true, lat, lon);
    }

    private void updateStartMarkerOnly(float lat, float lon) {
        this.startLatLon = new float[]{lat, lon};
        Vector3 pos3D = geoToWorld3D(lat, lon);
        if (pos3D != null && startMarkerModel != null) {
            startMarker = new ModelInstance(startMarkerModel);
            startMarker.transform.setTranslation(pos3D);
        }
    }

    public float[] getEndCoordinates() {
        return endLatLon;
    }

    public void setEndCoordinates(float lat, float lon) {
        updateEndMarkerOnly(lat, lon);
        sendPointToBackend(false, lat, lon);
    }

    private void updateEndMarkerOnly(float lat, float lon) {
        this.endLatLon = new float[]{lat, lon};
        Vector3 pos3D = geoToWorld3D(lat, lon);
        if (pos3D != null && endMarkerModel != null) {
            endMarker = new ModelInstance(endMarkerModel);
            endMarker.transform.setTranslation(pos3D);
        }
    }

    public void setRoute(List<float[]> waypointsLatLon) {
        if (routeModel != null) {
            routeModel.dispose();
            routeModel = null;
            routeInstance = null;
        }
        if (waypointsLatLon == null || waypointsLatLon.size() < 2) return;

        ModelBuilder mb = new ModelBuilder();
        mb.begin();
        MeshPartBuilder builder = mb.part("route", GL20.GL_LINES,
            VertexAttributes.Usage.Position | VertexAttributes.Usage.ColorUnpacked,
            new Material());
        builder.setColor(Color.GREEN);

        for (int i = 0; i < waypointsLatLon.size() - 1; i++) {
            float[] p1 = waypointsLatLon.get(i);
            float[] p2 = waypointsLatLon.get(i + 1);
            drawSegmentedLineOnTerrain(builder, p1[0], p1[1], p2[0], p2[1], 16, 0.55f);
        }

        routeModel = mb.end();
        routeInstance = new ModelInstance(routeModel);
    }

    public void setHazardCells(List<HazardCell3D> cells) {
        if (hazardModel != null) {
            hazardModel.dispose();
            hazardModel = null;
            hazardInstance = null;
        }
        if (cells == null || cells.isEmpty()) return;

        ModelBuilder mb = new ModelBuilder();
        mb.begin();
        MeshPartBuilder builder = mb.part("hazards", GL20.GL_LINES,
            VertexAttributes.Usage.Position | VertexAttributes.Usage.ColorUnpacked,
            new Material());

        for (HazardCell3D cell : cells) {
            builder.setColor(getColorForHazardType(cell.type));
            // Cell perimeter draped on 3D terrain
            drawSegmentedLineOnTerrain(builder, cell.latMin, cell.lonMin, cell.latMin, cell.lonMax, 6, 0.35f);
            drawSegmentedLineOnTerrain(builder, cell.latMin, cell.lonMax, cell.latMax, cell.lonMax, 6, 0.35f);
            drawSegmentedLineOnTerrain(builder, cell.latMax, cell.lonMax, cell.latMax, cell.lonMin, 6, 0.35f);
            drawSegmentedLineOnTerrain(builder, cell.latMax, cell.lonMin, cell.latMin, cell.lonMin, 6, 0.35f);
            // Diagonal X cross-hatch for visibility on the 3D crater
            drawSegmentedLineOnTerrain(builder, cell.latMin, cell.lonMin, cell.latMax, cell.lonMax, 6, 0.35f);
            drawSegmentedLineOnTerrain(builder, cell.latMin, cell.lonMax, cell.latMax, cell.lonMin, 6, 0.35f);
        }

        hazardModel = mb.end();
        hazardInstance = new ModelInstance(hazardModel);
    }

    public void setHazardZone(List<float[]> polygonLatLon) {
        if (hazardModel != null) {
            hazardModel.dispose();
            hazardModel = null;
            hazardInstance = null;
        }
        if (polygonLatLon == null || polygonLatLon.size() < 3) return;

        ModelBuilder mb = new ModelBuilder();
        mb.begin();
        MeshPartBuilder builder = mb.part("hazard", GL20.GL_LINES,
            VertexAttributes.Usage.Position | VertexAttributes.Usage.ColorUnpacked,
            new Material());
        builder.setColor(Color.RED);

        for (int i = 0; i < polygonLatLon.size(); i++) {
            float[] p1 = polygonLatLon.get(i);
            float[] p2 = polygonLatLon.get((i + 1) % polygonLatLon.size());
            drawSegmentedLineOnTerrain(builder, p1[0], p1[1], p2[0], p2[1], 24, 0.40f);
        }

        hazardModel = mb.end();
        hazardInstance = new ModelInstance(hazardModel);
    }

    private Color getColorForHazardType(int type) {
        switch (type) {
            case 1: return Color.ORANGE;                  // CV Boulder
            case 2: return Color.GOLD;                    // CV Steep Slope
            case 3: return Color.RED;                     // Wokwi Ionizing Radiation Plume
            case 4: return Color.PURPLE;                  // Wokwi Perchlorate Salt Basin
            case 5: return new Color(0.96f, 0.64f, 0.38f, 1f); // Wokwi Dust Storm Squall
            case 6: return Color.CYAN;                    // Wokwi Cryo/Thermal Trap
            default: return Color.SCARLET;
        }
    }

    private void rebuildDirectRouteIfReady() {
        if (startLatLon != null && endLatLon != null) {
            List<float[]> directPath = new ArrayList<>();
            directPath.add(startLatLon);
            directPath.add(endLatLon);
            setRoute(directPath);
        }
    }

    private void drawSegmentedLineOnTerrain(
        MeshPartBuilder builder, float lat1, float lon1, float lat2, float lon2, int steps, float yOffset
    ) {
        Vector3 prevPoint = null;
        for (int s = 0; s <= steps; s++) {
            float t = (float) s / steps;
            float lat = lat1 + (lat2 - lat1) * t;
            float lon = lon1 + (lon2 - lon1) * t;
            Vector3 currentPoint = geoToWorld3D(lat, lon);
            if (currentPoint != null) {
                currentPoint.y += yOffset;
                if (prevPoint != null) {
                    builder.line(prevPoint, currentPoint);
                }
                prevPoint = currentPoint;
            }
        }
    }

    private void enforceCameraTerrainCollision() {
        float groundY = getGroundHeight(camera.position.x, camera.position.z);
        float minAllowedY = groundY + MIN_CAMERA_CLEARANCE;
        if (camera.position.y < minAllowedY) {
            camera.position.y = minAllowedY;
            camera.update();
        }
    }

    private void drawHoverCrosshair() {
        if (hoverHitPoint == null) return;
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);
        shapeRenderer.setProjectionMatrix(camera.combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
        shapeRenderer.setColor(Color.CYAN);
        float x = hoverHitPoint.x;
        float y = hoverHitPoint.y + 0.15f;
        float z = hoverHitPoint.z;
        float crossSize = 2.5f;
        shapeRenderer.line(x, y, z, x, y + 10f, z);
        shapeRenderer.line(x - crossSize, y, z, x + crossSize, y, z);
        shapeRenderer.line(x, y, z - crossSize, x, y, z + crossSize);
        shapeRenderer.end();
    }

    private Vector3 geoToWorld3D(float lat, float lon) {
        float clampedLat = MathUtils.clamp(lat, GALE_LAT_MIN, GALE_LAT_MAX);
        float clampedLon = MathUtils.clamp(lon, GALE_LON_MIN, GALE_LON_MAX);
        float worldX = lonToWorldX(clampedLon);
        float worldZ = latToWorldZ(clampedLat);
        float groundY = getGroundHeight(worldX, worldZ);
        return new Vector3(worldX, groundY, worldZ);
    }

    private float getGroundHeight(float worldX, float worldZ) {
        Ray downRay = new Ray(new Vector3(worldX, 200f, worldZ), new Vector3(0f, -1f, 0f));
        Vector3 hit = new Vector3();
        if (intersectCrater(downRay, hit)) {
            return hit.y;
        }
        return -15f;
    }

    private float lonToWorldX(float lon) {
        return ((lon - CENTER_LON) / DEG_SPAN) * MODEL_SIZE;
    }

    private float latToWorldZ(float lat) {
        return -((lat - CENTER_LAT) / DEG_SPAN) * MODEL_SIZE;
    }

    private float worldXToLon(float worldX) {
        return CENTER_LON + ((worldX / MODEL_SIZE) * DEG_SPAN);
    }

    private float worldZToLat(float worldZ) {
        return CENTER_LAT + ((-worldZ / MODEL_SIZE) * DEG_SPAN);
    }

    private String formatCoord(float value) {
        float rounded = Math.round(value * 10000f) / 10000f;
        return Float.toString(rounded);
    }

    private void handleMapClick(int screenX, int screenY, boolean setPointA) {
        Ray ray = camera.getPickRay(screenX, screenY);
        Vector3 hitPoint = new Vector3();
        if (intersectCrater(ray, hitPoint)) {
            float lat = worldZToLat(hitPoint.z);
            float lon = worldXToLon(hitPoint.x);
            if (setPointA) {
                setStartCoordinates(lat, lon);
                Gdx.app.log("MARS", "Point A (Start) -> Lat: " + lat + ", Lon: " + lon);
            } else {
                setEndCoordinates(lat, lon);
                Gdx.app.log("MARS", "Point B (Target) -> Lat: " + lat + ", Lon: " + lon);
            }
        }
    }

    private void updateHoverCoordinates(int screenX, int screenY) {
        Ray ray = camera.getPickRay(screenX, screenY);
        Vector3 hit = new Vector3();
        if (intersectCrater(ray, hit)) {
            hoverHitPoint = new Vector3(hit);
            float lat = worldZToLat(hit.z);
            float lon = worldXToLon(hit.x);
            coordsText = "Cursor -> Lat: " + formatCoord(lat) + " deg, Lon: " + formatCoord(lon)
                + " deg | RMB: Set Point A | Shift+RMB / MMB: Set Point B | Keys [R/S/D/T/A/C/1/2/3]";
        } else {
            hoverHitPoint = null;
            coordsText = "Cursor Outside Crater | RMB: Set Point A | Shift+RMB / MMB: Set Point B | Keys [R/S/D/T/A/C/1/2/3]";
        }
    }

    private void extractMeshData() {
        int totalTriangles = 0;
        for (Mesh mesh : craterModel.meshes) {
            int numIndices = mesh.getNumIndices();
            totalTriangles += (numIndices > 0) ? (numIndices / 3) : (mesh.getNumVertices() / 3);
        }
        craterTriangles = new float[totalTriangles * 9];
        int triOffset = 0;
        Vector3 v1 = new Vector3();
        Vector3 v2 = new Vector3();
        Vector3 v3 = new Vector3();
        for (Mesh mesh : craterModel.meshes) {
            int numVertices = mesh.getNumVertices();
            int vertexSize = mesh.getVertexSize() / 4;
            float[] rawVertices = new float[numVertices * vertexSize];
            mesh.getVertices(rawVertices);
            int numIndices = mesh.getNumIndices();
            if (numIndices > 0) {
                short[] rawIndices = new short[numIndices];
                mesh.getIndices(rawIndices);
                for (int i = 0; i < numIndices; i += 3) {
                    int idx1 = rawIndices[i] & 0xFFFF;
                    int idx2 = rawIndices[i + 1] & 0xFFFF;
                    int idx3 = rawIndices[i + 2] & 0xFFFF;
                    v1.set(rawVertices[idx1 * vertexSize], rawVertices[idx1 * vertexSize + 1], rawVertices[idx1 * vertexSize + 2]).mul(craterInstance.transform);
                    v2.set(rawVertices[idx2 * vertexSize], rawVertices[idx2 * vertexSize + 1], rawVertices[idx2 * vertexSize + 2]).mul(craterInstance.transform);
                    v3.set(rawVertices[idx3 * vertexSize], rawVertices[idx3 * vertexSize + 1], rawVertices[idx3 * vertexSize + 2]).mul(craterInstance.transform);
                    craterTriangles[triOffset++] = v1.x; craterTriangles[triOffset++] = v1.y; craterTriangles[triOffset++] = v1.z;
                    craterTriangles[triOffset++] = v2.x; craterTriangles[triOffset++] = v2.y; craterTriangles[triOffset++] = v2.z;
                    craterTriangles[triOffset++] = v3.x; craterTriangles[triOffset++] = v3.y; craterTriangles[triOffset++] = v3.z;
                }
            } else {
                for (int i = 0; i < numVertices; i += 3) {
                    v1.set(rawVertices[i * vertexSize], rawVertices[i * vertexSize + 1], rawVertices[i * vertexSize + 2]).mul(craterInstance.transform);
                    v2.set(rawVertices[(i + 1) * vertexSize], rawVertices[(i + 1) * vertexSize + 1], rawVertices[(i + 1) * vertexSize + 2]).mul(craterInstance.transform);
                    v3.set(rawVertices[(i + 2) * vertexSize], rawVertices[(i + 2) * vertexSize + 1], rawVertices[(i + 2) * vertexSize + 2]).mul(craterInstance.transform);
                    craterTriangles[triOffset++] = v1.x; craterTriangles[triOffset++] = v1.y; craterTriangles[triOffset++] = v1.z;
                    craterTriangles[triOffset++] = v2.x; craterTriangles[triOffset++] = v2.y; craterTriangles[triOffset++] = v2.z;
                    craterTriangles[triOffset++] = v3.x; craterTriangles[triOffset++] = v3.y; craterTriangles[triOffset++] = v3.z;
                }
            }
        }
    }

    private boolean intersectCrater(Ray ray, Vector3 bestHit) {
        if (craterTriangles == null) return false;
        boolean found = false;
        float minDist = Float.MAX_VALUE;
        Vector3 t1 = new Vector3();
        Vector3 t2 = new Vector3();
        Vector3 t3 = new Vector3();
        Vector3 tmpHit = new Vector3();
        for (int i = 0; i < craterTriangles.length; i += 9) {
            t1.set(craterTriangles[i], craterTriangles[i + 1], craterTriangles[i + 2]);
            t2.set(craterTriangles[i + 3], craterTriangles[i + 4], craterTriangles[i + 5]);
            t3.set(craterTriangles[i + 6], craterTriangles[i + 7], craterTriangles[i + 8]);
            if (Intersector.intersectRayTriangle(ray, t1, t2, t3, tmpHit)) {
                float dist = ray.origin.dst2(tmpHit);
                if (dist < minDist) {
                    minDist = dist;
                    bestHit.set(tmpHit);
                    found = true;
                }
            }
        }
        return found;
    }

    @Override
    public void render() {
        float dt = Gdx.graphics.getDeltaTime();
        pollTimer += dt;
        if (pollTimer >= POLL_INTERVAL_SEC) {
            pollTimer = 0f;
            pollBackendState();
        }

        camController.update();
        enforceCameraTerrainCollision();
        updateHoverCoordinates(Gdx.input.getX(), Gdx.input.getY());

        Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        if (dustStormActive) {
            Gdx.gl.glClearColor(0.28f, 0.14f, 0.08f, 1f);
        } else {
            Gdx.gl.glClearColor(0.08f, 0.08f, 0.10f, 1f);
        }
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        Gdx.gl.glLineWidth(3.5f);

        modelBatch.begin(camera);
        modelBatch.render(craterInstance, environment);
        if (startMarker != null) modelBatch.render(startMarker, environment);
        if (endMarker != null) modelBatch.render(endMarker, environment);
        if (routeInstance != null) modelBatch.render(routeInstance);
        if (hazardInstance != null) modelBatch.render(hazardInstance);
        modelBatch.end();

        drawHoverCrosshair();

        // Render Live Telemetry & Navigation HUD
        int h = Gdx.graphics.getHeight();
        uiBatch.begin();

        font.setColor(Color.CYAN);
        font.draw(uiBatch, telemetryHeader, 16, h - 14);

        if (hazardBanner.contains("ACTIVE WOKWI HAZARDS")) {
            font.setColor(Color.SCARLET);
        } else {
            font.setColor(Color.GREEN);
        }
        font.draw(uiBatch, hazardBanner, 16, h - 36);

        font.setColor(Color.YELLOW);
        font.draw(uiBatch, routeMetricsText, 16, h - 58);

        font.setColor(Color.LIGHT_GRAY);
        font.draw(uiBatch, pointAInfo + "   --->   " + pointBInfo, 16, h - 80);

        font.setColor(Color.WHITE);
        int maxLines = Math.min(navInstructions.size(), 5);
        for (int i = 0; i < maxLines; i++) {
            font.draw(uiBatch, navInstructions.get(i), 16, h - 106 - (i * 20));
        }

        font.setColor(Color.WHITE);
        font.draw(uiBatch, coordsText, 16, 28);
        uiBatch.end();
    }

    @Override
    public void resize(int width, int height) {
        camera.viewportWidth = width;
        camera.viewportHeight = height;
        camera.update();
        uiBatch.getProjectionMatrix().setToOrtho2D(0, 0, width, height);
    }

    @Override
    public void dispose() {
        modelBatch.dispose();
        uiBatch.dispose();
        shapeRenderer.dispose();
        font.dispose();
        craterModel.dispose();
        startMarkerModel.dispose();
        endMarkerModel.dispose();
        if (routeModel != null) routeModel.dispose();
        if (hazardModel != null) hazardModel.dispose();
    }
}
